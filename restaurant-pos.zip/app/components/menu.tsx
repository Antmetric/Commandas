"use client"

import { useState, useEffect } from "react"
import { Plus, Minus, Edit, Trash, Save } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet"
import { useOrder } from "../contexts/order-context"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"

interface Dish {
  id: string
  name: string
  description: string
  price: number
  type: "prato" | "bebida"
}

interface OrderItem extends Dish {
  quantity: number
}

interface Order {
  id: string
  tableNumber: string
  items: OrderItem[]
  status: string
  total: number
  createdAt: Date
}

export function Menu({ isAdminView = false }) {
  const [dishes, setDishes] = useState<Dish[]>([
    {
      id: "1",
      name: "Thai Rice Bowl",
      description: "Arroz tailandês com legumes e frango",
      price: 27.09,
      type: "prato",
    },
    {
      id: "2",
      name: "Smoke Salmon Rice Bowl",
      description: "Bowl de arroz com salmão defumado",
      price: 32.5,
      type: "prato",
    },
    { id: "3", name: "Coca-Cola", description: "Refrigerante 350ml", price: 5.0, type: "bebida" },
  ])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingDish, setEditingDish] = useState<Dish | null>(null)
  const [newDish, setNewDish] = useState<Omit<Dish, "id">>({ name: "", description: "", price: 0, type: "prato" })
  const [isEditMode, setIsEditMode] = useState(false)
  const [isEditingMenu, setIsEditingMenu] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [currentOrder, setCurrentOrder] = useState<{ [key: string]: number }>({})

  const router = useRouter()
  const { toast } = useToast()

  // Wrap the useOrder hook in a try-catch to handle cases where it might be used outside of an OrderProvider
  let addOrder
  let orderContextError = null
  let orderContextValue = null

  try {
    orderContextValue = useOrder()
    addOrder = orderContextValue.addOrder
  } catch (error) {
    console.error("OrderProvider not found:", error)
    orderContextError = error
    addOrder = () => {
      console.warn("Order could not be added: OrderProvider not found")
    }
  }

  const handleEditMenu = () => {
    setIsEditingMenu(true)
  }

  const handleSaveMenu = () => {
    setIsEditingMenu(false)
    // Save all dishes to localStorage
    localStorage.setItem("menuDishes", JSON.stringify(dishes))
    // Here you can also add logic to save to a backend if needed
    console.log("Pratos salvos:", dishes)
    toast({
      title: "Sucesso",
      description: "Todos os pratos foram salvos com sucesso.",
    })
  }

  const handleAddDish = (type: "prato" | "bebida") => {
    if (newDish.name && newDish.description && newDish.price > 0) {
      setDishes([...dishes, { ...newDish, id: Date.now().toString(), type }])
      setNewDish({ name: "", description: "", price: 0, type: "prato" })
      setIsDialogOpen(false)
    }
  }

  const handleEditDish = () => {
    if (editingDish) {
      setDishes(dishes.map((dish) => (dish.id === editingDish.id ? editingDish : dish)))
      setEditingDish(null)
      setIsDialogOpen(false)
    }
  }

  const handleDeleteDish = (id: string) => {
    setDishes(dishes.filter((dish) => dish.id !== id))
  }

  const handleAddToOrder = (dish: Dish) => {
    setCurrentOrder((prev) => ({
      ...prev,
      [dish.id]: (prev[dish.id] || 0) + 1,
    }))
    setIsSidebarOpen(true)
  }

  const handleUpdateQuantity = (dishId: string, increment: number) => {
    setCurrentOrder((prev) => {
      const newQuantity = (prev[dishId] || 0) + increment
      if (newQuantity <= 0) {
        const { [dishId]: _, ...rest } = prev
        return rest
      }
      return { ...prev, [dishId]: newQuantity }
    })
  }

  const calculateTotal = () => {
    return Object.entries(currentOrder).reduce((total, [dishId, quantity]) => {
      const dish = dishes.find((d) => d.id === dishId)
      return total + (dish?.price || 0) * quantity
    }, 0)
  }

  const handleConfirmOrder = () => {
    if (Object.keys(currentOrder).length === 0) {
      toast({
        title: "Erro",
        description: "Adicione itens ao pedido antes de confirmar.",
        variant: "destructive",
      })
      return
    }

    const orderItems = Object.entries(currentOrder).map(([dishId, quantity]) => {
      const dish = dishes.find((d) => d.id === dishId)
      return {
        id: dish!.id,
        name: dish!.name,
        quantity: quantity,
        price: dish!.price,
      }
    })

    const newOrder = {
      id: Date.now().toString(),
      tableNumber: "1", // Substitua isso pelo número real da mesa
      items: orderItems,
      status: "pending",
      total: calculateTotal(),
      createdAt: new Date(),
    }

    addOrder(newOrder)

    setCurrentOrder({})
    setIsSidebarOpen(false)

    toast({
      title: "Pedido Confirmado",
      description: "Seu pedido foi enviado para a cozinha com sucesso!",
      duration: 3000,
    })

    router.push("/kitchen")
  }

  const renderCardapio = () => (
    <div className="w-full">
      {isAdminView && (
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Cardápio</h2>
          <Button onClick={handleEditMenu}>Editar Cardápio</Button>
        </div>
      )}
      <div className="mb-8">
        <h3 className="text-xl font-semibold mb-4">Menu</h3>
        <div className="flex flex-wrap gap-4">
          {dishes
            .filter((dish) => dish.type === "prato")
            .map((dish) => (
              <Card key={dish.id} className="w-64 flex flex-col">
                <CardHeader>
                  <CardTitle className="text-lg">{dish.name}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-sm">{dish.description}</p>
                  <p className="font-bold mt-2">R$ {dish.price.toFixed(2)}</p>
                  {!isAdminView && (
                    <Button className="w-full mt-4 text-sm" onClick={() => handleAddToOrder(dish)}>
                      Adicionar ao Pedido
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
      <div>
        <h3 className="text-xl font-semibold mb-4">Bebidas</h3>
        <div className="flex flex-wrap gap-4">
          {dishes
            .filter((dish) => dish.type === "bebida")
            .map((dish) => (
              <Card key={dish.id} className="w-64 flex flex-col">
                <CardHeader>
                  <CardTitle className="text-lg">{dish.name}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-sm">{dish.description}</p>
                  <p className="font-bold mt-2">R$ {dish.price.toFixed(2)}</p>
                  {!isAdminView && (
                    <Button className="w-full mt-4 text-sm" onClick={() => handleAddToOrder(dish)}>
                      Adicionar ao Pedido
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
        </div>
      </div>
    </div>
  )

  const renderEditCardapio = () => (
    <>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Editar Cardápio</h2>
        <div className="space-x-2">
          <Button
            onClick={() => {
              setNewDish({ ...newDish, type: "bebida" })
              setIsDialogOpen(true)
            }}
            className="mr-2"
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Bebida
          </Button>
          <Button
            onClick={() => {
              setNewDish({ ...newDish, type: "prato" })
              setIsDialogOpen(true)
            }}
            className="mr-2"
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Prato
          </Button>
          <Button onClick={handleSaveMenu} variant="outline" className="bg-green-600 hover:bg-green-700 text-white">
            <Save className="h-4 w-4 mr-2" />
            Salvar Todos os Pratos
          </Button>
        </div>
      </div>

      <div className="space-y-8">
        <div>
          <h3 className="text-xl font-semibold mb-4">Pratos</h3>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-1/4">Nome</TableHead>
                <TableHead className="w-1/2">Descrição</TableHead>
                <TableHead className="w-1/8">Preço</TableHead>
                <TableHead className="w-1/8">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dishes
                .filter((dish) => dish.type === "prato")
                .map((dish) => (
                  <TableRow key={dish.id}>
                    <TableCell className="font-medium">{dish.name}</TableCell>
                    <TableCell>{dish.description}</TableCell>
                    <TableCell>R${dish.price.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingDish(dish)
                            setIsDialogOpen(true)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteDish(dish.id)}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>

        <div>
          <h3 className="text-xl font-semibold mb-4">Bebidas</h3>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-1/4">Nome</TableHead>
                <TableHead className="w-1/2">Descrição</TableHead>
                <TableHead className="w-1/8">Preço</TableHead>
                <TableHead className="w-1/8">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dishes
                .filter((dish) => dish.type === "bebida")
                .map((dish) => (
                  <TableRow key={dish.id}>
                    <TableCell className="font-medium">{dish.name}</TableCell>
                    <TableCell>{dish.description}</TableCell>
                    <TableCell>R${dish.price.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingDish(dish)
                            setIsDialogOpen(true)
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteDish(dish.id)}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </>
  )

  useEffect(() => {
    const savedDishes = localStorage.getItem("menuDishes")
    if (savedDishes) {
      setDishes(JSON.parse(savedDishes))
    }
  }, [])

  // We've already called useOrder at the beginning of the component,
  // so we don't need to call it again here.
  // If you need to use addOrder, you can use the one defined earlier in the component.

  return (
    <div className="w-full h-full overflow-auto p-6">
      {isAdminView && isEditingMenu ? renderEditCardapio() : renderCardapio()}
      {/* Dialog para adicionar/editar pratos */}
      <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
        <SheetContent>
          <SheetHeader>
            <SheetTitle>Seu Pedido</SheetTitle>
          </SheetHeader>
          <div className="mt-4 space-y-4">
            {Object.entries(currentOrder).map(([dishId, quantity]) => {
              const dish = dishes.find((d) => d.id === dishId)
              if (!dish) return null
              return (
                <div key={dishId} className="flex justify-between items-center">
                  <div>
                    <span className="font-medium">{dish.name}</span>
                    <p className="text-sm text-gray-500">Quantidade: {quantity}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button size="sm" variant="outline" onClick={() => handleUpdateQuantity(dishId, -1)}>
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleUpdateQuantity(dishId, 1)}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
          <SheetFooter className="mt-4">
            <div className="flex justify-between items-center w-full">
              <span className="font-bold">Total: R$ {calculateTotal().toFixed(2)}</span>
              <Button onClick={handleConfirmOrder}>Confirmar Pedido</Button>
            </div>
          </SheetFooter>
        </SheetContent>
      </Sheet>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingDish ? "Editar Item" : `Adicionar ${newDish.type === "prato" ? "Prato" : "Bebida"}`}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Nome do Item"
              value={editingDish ? editingDish.name : newDish.name}
              onChange={(e) =>
                editingDish
                  ? setEditingDish({ ...editingDish, name: e.target.value })
                  : setNewDish({ ...newDish, name: e.target.value })
              }
            />
            <Textarea
              placeholder="Descrição do Item"
              value={editingDish ? editingDish.description : newDish.description}
              onChange={(e) =>
                editingDish
                  ? setEditingDish({ ...editingDish, description: e.target.value })
                  : setNewDish({ ...newDish, description: e.target.value })
              }
            />
            <Input
              type="number"
              placeholder="Preço"
              value={editingDish ? editingDish.price : newDish.price}
              onChange={(e) => {
                const price = Number.parseFloat(e.target.value)
                editingDish ? setEditingDish({ ...editingDish, price }) : setNewDish({ ...newDish, price })
              }}
            />
          </div>
          <DialogFooter>
            <Button onClick={() => (editingDish ? handleEditDish() : handleAddDish(newDish.type))}>
              {editingDish ? "Salvar Alterações" : "Adicionar Item"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

