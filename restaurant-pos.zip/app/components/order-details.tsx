"use client"

import Image from "next/image"
import { Pencil } from "lucide-react"
import { Button } from "@/components/ui/button"

interface OrderItem {
  id: string
  name: string
  image: string
  quantity: number
  price: number
  status: "ready" | "preparing" | "pending"
  prepTime?: string
}

const orderItems: OrderItem[] = [
  {
    id: "1",
    name: "Coca Cola",
    image: "/placeholder.svg",
    quantity: 1,
    price: 3.2,
    status: "ready",
  },
  {
    id: "2",
    name: "Hamburger",
    image: "/placeholder.svg",
    quantity: 3,
    price: 9.6,
    status: "ready",
  },
  {
    id: "3",
    name: "Pizza Diabola",
    image: "/placeholder.svg",
    quantity: 1,
    price: 15.0,
    status: "preparing",
    prepTime: "12 min",
  },
  {
    id: "4",
    name: "Greek Salat",
    image: "/placeholder.svg",
    quantity: 1,
    price: 4.5,
    status: "pending",
    prepTime: "3 min",
  },
]

export function OrderDetails() {
  const total = orderItems.reduce((acc, item) => acc + item.price * item.quantity, 0)

  return (
    <div className="flex-1 p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold">Mesa №8</h1>
            <button className="text-blue-500">
              <Pencil className="w-4 h-4" />
            </button>
          </div>
          <div className="flex gap-4 text-sm text-gray-500 mt-1">
            <span>Horário do pedido: 19:12</span>
            <span>Pedido nº: 8374</span>
          </div>
        </div>
        <Button>Adicionar Prato</Button>
      </div>

      <div className="space-y-4">
        {orderItems.map((item) => (
          <div key={item.id} className="flex items-center gap-4 p-4 rounded-xl border border-gray-100">
            <div className="relative w-12 h-12">
              <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover rounded-lg" />
            </div>
            <div className="flex-1">
              <div className="flex justify-between">
                <div>
                  <h3 className="font-medium">{item.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm text-gray-500">x{item.quantity}</span>
                    {item.status === "ready" && (
                      <span className="text-sm text-green-500 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                        Pronto
                      </span>
                    )}
                    {item.prepTime && <span className="text-sm text-gray-500">{item.prepTime}</span>}
                  </div>
                </div>
                <span className="font-medium">$ {(item.price * item.quantity).toFixed(2)}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-6 border-t border-gray-100">
        <div className="flex justify-between items-center">
          <span className="text-gray-500">Total:</span>
          <span className="text-xl font-semibold">$ {total.toFixed(2)}</span>
        </div>
      </div>
    </div>
  )
}

