"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useTableContext } from "../contexts/table-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"
import { Input } from "@/components/ui/input"
import { Menu } from "./menu"
import { useToast } from "@/components/ui/use-toast"
import { OrderProvider } from "../contexts/order-context"
import { MenuIcon, X } from "lucide-react"

const statistics = {
  ordersToday: 245,
  revenue: 1688,
  totalCustomers: 3421,
  activeOrders: 256,
}

const bestSellers = [
  {
    name: "Picanha ao Ponto",
    rating: 4.8,
    image: "/placeholder.svg?height=50&width=50",
  },
  {
    name: "Camarão Internacional",
    rating: 4.6,
    image: "/placeholder.svg?height=50&width=50",
  },
]

interface EditingTable {
  id: string
  number: string
  status: "available" | "occupied" | "reserved"
  capacity: number
}

export function AdminDashboard() {
  const [currentView, setCurrentView] = useState<"dashboard" | "mesas-admin" | "menu" | "funcionarios" | "chaves-pix">(
    "dashboard",
  )
  const { tables, updateTable, removeTable, addTable } = useTableContext()

  const [newTableNumber, setNewTableNumber] = useState("")
  const [editingTable, setEditingTable] = useState<EditingTable | null>(null)

  const [pixKey, setPixKey] = useState("")
  const [qrCodeImage, setQrCodeImage] = useState<string | null>(null)
  const { toast } = useToast()
  const [isSaving, setIsSaving] = useState(false)
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)

  useEffect(() => {
    const savedPixKey = localStorage.getItem("pixKey")
    const savedQrCodeImage = localStorage.getItem("qrCodeImage")
    if (savedPixKey) setPixKey(savedPixKey)
    if (savedQrCodeImage) setQrCodeImage(savedQrCodeImage)
  }, [])

  const handleAddTable = () => {
    if (newTableNumber) {
      addTable({
        id: Date.now().toString(),
        number: newTableNumber,
        status: "available",
        capacity: 4,
      })
      setNewTableNumber("")
    }
  }

  const handleEditTable = () => {
    if (editingTable) {
      updateTable({
        id: editingTable.id,
        number: editingTable.number,
        status: editingTable.status,
        capacity: editingTable.capacity,
      })
      setEditingTable(null)
    }
  }

  const handleRemoveTable = (id: string) => {
    if (window.confirm("Tem certeza que deseja remover esta mesa?")) {
      removeTable(id)
    }
  }

  const renderMesasAdmin = () => {
    const sortedTables = [...tables].sort((a, b) => Number(b.number) - Number(a.number))

    return (
      <div className="overflow-x-auto">
        <h2 className="text-xl font-bold mb-4">Gerenciamento de Mesas</h2>
        <div className="flex flex-col sm:flex-row gap-2 mb-4">
          <Input
            type="text"
            value={newTableNumber}
            onChange={(e) => setNewTableNumber(e.target.value)}
            placeholder="Número da nova mesa"
            className="w-full sm:w-auto"
          />
          <Button onClick={handleAddTable} className="w-full sm:w-auto">
            Adicionar Mesa
          </Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Número</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Capacidade</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedTables.map((table) => (
              <TableRow key={table.id}>
                <TableCell>
                  {editingTable?.id === table.id ? (
                    <Input
                      type="text"
                      value={editingTable.number}
                      onChange={(e) => setEditingTable({ ...editingTable, number: e.target.value })}
                    />
                  ) : (
                    table.number
                  )}
                </TableCell>
                <TableCell>
                  {editingTable?.id === table.id ? (
                    <select
                      value={editingTable.status}
                      onChange={(e) =>
                        setEditingTable({ ...editingTable, status: e.target.value as EditingTable["status"] })
                      }
                      className="border rounded p-1"
                    >
                      <option value="available">Disponível</option>
                      <option value="occupied">Ocupada</option>
                      <option value="reserved">Reservada</option>
                    </select>
                  ) : (
                    table.status
                  )}
                </TableCell>
                <TableCell>
                  {editingTable?.id === table.id ? (
                    <Input
                      type="number"
                      value={editingTable.capacity}
                      onChange={(e) =>
                        setEditingTable({ ...editingTable, capacity: Number.parseInt(e.target.value) || 0 })
                      }
                      className="w-20"
                    />
                  ) : (
                    table.capacity
                  )}
                </TableCell>
                <TableCell>
                  {editingTable?.id === table.id ? (
                    <Button onClick={handleEditTable} variant="outline" className="mr-2">
                      Salvar
                    </Button>
                  ) : (
                    <>
                      <Button
                        onClick={() =>
                          setEditingTable({
                            id: table.id,
                            number: table.number,
                            status: table.status as EditingTable["status"],
                            capacity: table.capacity || 0,
                          })
                        }
                        variant="outline"
                        className="mr-2"
                      >
                        Editar
                      </Button>
                      <Button onClick={() => handleRemoveTable(table.id)} variant="outline">
                        Remover
                      </Button>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    )
  }

  const handleSavePixConfig = () => {
    if (!pixKey) {
      toast({
        title: "Erro",
        description: "Por favor, preencha a chave PIX.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    try {
      localStorage.setItem("pixKey", pixKey)

      if (qrCodeImage) {
        localStorage.setItem("qrCodeImage", qrCodeImage)
      }

      toast({
        title: "Sucesso",
        description: "Configurações PIX salvas com sucesso!",
      })
    } catch (error) {
      console.error("Erro ao salvar configurações:", error)
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar as configurações.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen)
  }

  return (
    <div className="flex flex-col sm:flex-row h-screen bg-gray-100">
      {/* Mobile Header */}
      <div className="sm:hidden bg-gray-200 p-4 flex justify-between items-center">
        <h2 className="text-2xl font-semibold">Admin Dashboard</h2>
        <Button onClick={toggleSidebar} variant="ghost">
          {isSidebarOpen ? <X /> : <MenuIcon />}
        </Button>
      </div>

      {/* Sidebar */}
      <div className={`${isSidebarOpen ? "block" : "hidden"} sm:block w-full sm:w-64 bg-gray-200 p-4 sm:h-screen`}>
        <h2 className="text-2xl font-semibold mb-4 hidden sm:block">Admin Dashboard</h2>
        <nav>
          <ul className="space-y-2">
            {[
              { view: "dashboard", label: "Dashboard" },
              { view: "mesas-admin", label: "Gerenciar Mesas" },
              { view: "menu", label: "Exibir Cardápio" },
              { view: "funcionarios", label: "Funcionários" },
              { view: "chaves-pix", label: "Chaves PIX" },
            ].map((item) => (
              <li key={item.view}>
                <Button
                  onClick={() => {
                    setCurrentView(item.view as any)
                    setIsSidebarOpen(false)
                  }}
                  variant={currentView === item.view ? "default" : "outline"}
                  className={`w-full ${currentView === item.view ? "bg-red-600 text-white hover:bg-red-700" : ""}`}
                >
                  {item.label}
                </Button>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-4 overflow-auto">
        {currentView === "dashboard" && (
          <div>
            <h1 className="text-3xl font-semibold mb-4">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-800">{statistics.ordersToday}</div>
                      <div className="text-sm text-red-600">Pedidos Hoje</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-800">R$ {statistics.revenue}</div>
                      <div className="text-sm text-red-600">Receita Hoje</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-800">{statistics.totalCustomers}</div>
                      <div className="text-sm text-red-600">Total de Clientes</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-800">{statistics.activeOrders}</div>
                      <div className="text-sm text-red-600">Pedidos Ativos</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Mais Vendidos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {bestSellers.map((item, index) => (
                      <div key={index} className="flex items-center gap-4">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={50}
                          height={50}
                          className="rounded-lg"
                        />
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-red-600">★ {item.rating}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Pedidos Ativos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3].map((order) => (
                      <div key={order} className="p-3 bg-red-50 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-medium">Mesa #{order}</span>
                          <span className="text-sm text-red-600">12:45</span>
                        </div>
                        <div className="text-sm text-red-700">3 itens • R$ 156,90</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
        {currentView === "mesas-admin" && renderMesasAdmin()}
        {currentView === "menu" && (
          <OrderProvider>
            <Menu isAdminView={true} />
          </OrderProvider>
        )}
        {currentView === "funcionarios" && (
          <div>
            <h1 className="text-3xl font-semibold mb-4">Funcionários</h1>
            <p>Gerencie os funcionários aqui.</p>
          </div>
        )}
        {currentView === "chaves-pix" && (
          <div className="space-y-6">
            <h1 className="text-3xl font-semibold mb-4">Chaves PIX</h1>
            <div className="space-y-4">
              <div>
                <label htmlFor="pix-key" className="block text-sm font-medium text-gray-700 mb-1">
                  Chave PIX Aleatória
                </label>
                <Input
                  id="pix-key"
                  type="text"
                  placeholder="Digite a chave PIX aleatória"
                  className="w-full max-w-md"
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="qr-code" className="block text-sm font-medium text-gray-700 mb-1">
                  QR Code PIX
                </label>
                <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2">
                  <Input
                    id="qr-code"
                    type="file"
                    accept="image/*"
                    className="w-full max-w-md"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (file) {
                        const reader = new FileReader()
                        reader.onloadend = () => {
                          setQrCodeImage(reader.result as string)
                        }
                        reader.readAsDataURL(file)
                      }
                    }}
                  />
                  <Button variant="outline" onClick={() => document.getElementById("qr-code")?.click()}>
                    Anexar QR Code
                  </Button>
                </div>
              </div>
              {qrCodeImage && (
                <div>
                  <p>QR Code Preview:</p>
                  <img src={qrCodeImage || "/placeholder.svg"} alt="QR Code Preview" className="mt-2 max-w-xs" />
                </div>
              )}
              <Button
                className="mt-4 bg-red-600 hover:bg-red-700 text-white"
                onClick={handleSavePixConfig}
                disabled={isSaving}
              >
                {isSaving ? "Salvando..." : "Salvar Configurações PIX"}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

