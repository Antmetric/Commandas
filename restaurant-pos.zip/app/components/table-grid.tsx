"use client"

import { useState } from "react"
import { LayoutGrid, UtensilsCrossed, MessageSquare, Settings } from "lucide-react"
import { cn } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Table {
  id: string
  number: string
  status: "available" | "occupied" | "reserved"
  timeLeft?: string
}

const tables: Table[] = [
  { id: "1", number: "01", status: "occupied", timeLeft: "7 min" },
  { id: "2", number: "02", status: "available" },
  { id: "3", number: "03", status: "reserved" },
  { id: "4", number: "04", status: "occupied" },
  { id: "5", number: "05", status: "available" },
  { id: "6", number: "06", status: "available" },
  { id: "7", number: "07", status: "occupied", timeLeft: "32 min" },
  { id: "8", number: "08", status: "occupied", timeLeft: "12 min" },
  { id: "9", number: "09", status: "available" },
  { id: "10", number: "10", status: "occupied", timeLeft: "2 min" },
  { id: "11", number: "11", status: "available" },
  { id: "12", number: "12", status: "available" },
]

export function TableGrid() {
  const [selectedTable, setSelectedTable] = useState<string>()

  return (
    <div className="w-72 bg-white">
      <div className="p-4 border-b border-gray-100">
        <Select defaultValue="all">
          <SelectTrigger>
            <SelectValue placeholder="Selecionar filtro" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as mesas</SelectItem>
            <SelectItem value="available">Disponíveis</SelectItem>
            <SelectItem value="occupied">Ocupadas</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="border-r border-gray-100">
        <div className="flex flex-col gap-6 items-center py-6">
          <button className="w-12 h-12 flex items-center justify-center rounded-xl bg-blue-600 text-white">
            <LayoutGrid className="w-6 h-6" />
          </button>
          <button className="w-12 h-12 flex items-center justify-center rounded-xl text-gray-400 hover:bg-gray-50">
            <UtensilsCrossed className="w-6 h-6" />
          </button>
          <button className="w-12 h-12 flex items-center justify-center rounded-xl text-gray-400 hover:bg-gray-50">
            <MessageSquare className="w-6 h-6" />
          </button>
          <button className="w-12 h-12 flex items-center justify-center rounded-xl text-gray-400 hover:bg-gray-50">
            <Settings className="w-6 h-6" />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4 p-4">
          {tables.map((table) => (
            <button
              key={table.id}
              onClick={() => setSelectedTable(table.id)}
              className={cn(
                "relative h-20 rounded-xl border-2 border-dashed flex flex-col items-center justify-center gap-1",
                table.status === "available"
                  ? "border-gray-200 text-gray-500 hover:border-blue-500 hover:text-blue-500"
                  : table.status === "occupied"
                    ? "border-solid border-blue-500 bg-blue-50 text-blue-500"
                    : "border-gray-200 text-gray-300",
                selectedTable === table.id && "ring-2 ring-blue-500",
              )}
            >
              <span className="text-lg font-semibold">{table.number}</span>
              {table.timeLeft && <span className="text-xs">{table.timeLeft}</span>}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

