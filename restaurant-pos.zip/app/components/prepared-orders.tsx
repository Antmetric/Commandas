"use client"

import { CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface PreparedItem {
  id: string
  name: string
  quantity: number
  table: string
  status: "ready" | "delivered"
}

const preparedItems: PreparedItem[] = [
  { id: "1", name: "Pizza Bianca", quantity: 1, table: "7", status: "ready" },
  { id: "2", name: "Pizza Venece", quantity: 4, table: "6", status: "ready" },
  { id: "3", name: "Cesar Salat", quantity: 4, table: "7", status: "ready" },
  { id: "4", name: "Carlsberg Beer", quantity: 4, table: "6", status: "ready" },
  { id: "5", name: "Obolon Beer", quantity: 4, table: "7", status: "ready" },
  { id: "6", name: "Morshynska Water", quantity: 4, table: "11", status: "ready" },
]

export function PreparedOrders() {
  return (
    <div className="p-4">
      <div className="mb-8">
        <div className="bg-white rounded-xl border border-gray-100 p-4">
          <h2 className="text-sm font-medium mb-2">TEMPO RESTANTE ATÉ O PEDIDO FICAR PRONTO</h2>
          <div className="relative w-32 h-32 mx-auto">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <circle
                className="text-gray-100"
                strokeWidth="8"
                stroke="currentColor"
                fill="transparent"
                r="42"
                cx="50"
                cy="50"
              />
              <circle
                className="text-blue-600"
                strokeWidth="8"
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
                r="42"
                cx="50"
                cy="50"
                strokeDasharray="264, 264"
                strokeDashoffset="66"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-2xl font-bold">12:23</div>
          </div>
          <Button variant="outline" className="w-full mt-4">
            Fechar Pedido
          </Button>
        </div>
      </div>

      <div>
        <h2 className="text-sm font-medium mb-4">PRATOS PREPARADOS</h2>
        <div className="space-y-3">
          {preparedItems.map((item) => (
            <div key={item.id} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                <span>{item.name}</span>
                <span className="text-gray-500">x{item.quantity}</span>
              </div>
              <span className="text-gray-500">Mesa №{item.table}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

