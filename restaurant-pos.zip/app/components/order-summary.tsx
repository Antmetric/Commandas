"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { useOrder } from "../contexts/order-context"
import { useTableContext } from "../contexts/table-context"
import { updateCashRegister } from "../actions/orders"
import { useRouter } from "next/navigation"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"

export function OrderSummary() {
  const { orders, addOrder, updateOrderStatus } = useOrder()
  const { updateTableStatus } = useTableContext()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const searchParams = useSearchParams()
  const [tableNumber, setTableNumber] = useState(searchParams.get("mesa") || "")
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const mesa = searchParams.get("mesa")
    if (mesa) {
      setTableNumber(mesa)
    }
  }, [searchParams])

  const currentOrder = orders.find((order) => order.tableNumber === tableNumber && order.status === "pending")

  useEffect(() => {
    if (currentOrder && currentOrder.items.length > 0) {
      setIsVisible(true)
    } else {
      setIsVisible(false)
    }
  }, [currentOrder])

  const handleCloseSidebar = () => {
    if (currentOrder && currentOrder.items.length > 0) {
      if (confirm("Tem certeza que deseja fechar? Seu pedido atual será perdido.")) {
        updateOrderStatus(currentOrder.id, "cancelled")
        router.push("/")
      }
    } else {
      router.push("/")
    }
  }

  const subtotal = currentOrder ? currentOrder.items.reduce((acc, item) => acc + item.price * item.quantity, 0) : 0
  const discount = currentOrder && currentOrder.items.length > 0 ? 5.0 : 0
  const tax = subtotal * 0.1
  const total = subtotal - discount + tax

  const handleFinishOrder = () => {
    if (!tableNumber) {
      toast({
        title: "Erro",
        description: "Por favor, insira o número da mesa",
        variant: "destructive",
      })
      return
    }
    setIsConfirmationOpen(true)
  }

  const confirmFinishOrder = async () => {
    setIsConfirmationOpen(false)
    setIsSubmitting(true)
    try {
      if (currentOrder) {
        await updateOrderStatus(currentOrder.id, "preparing")
        updateTableStatus(tableNumber, "esperando")

        // Atualizar histórico e valor no caixa
        await updateCashRegister({ total, tableNumber })

        toast({
          title: "Sucesso!",
          description: "Pedido enviado para a cozinha",
        })

        // Voltar para a tela anterior
        router.push("/")
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível enviar o pedido",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (!currentOrder || currentOrder.items.length === 0) {
    return null // Não renderiza nada se não houver itens no pedido
  }

  if (!isVisible) {
    return null
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex flex-col gap-4 mb-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Pedido</h1>
          <Button variant="ghost" size="icon" onClick={handleCloseSidebar}>
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <label htmlFor="table-number" className="text-sm font-medium">
            Mesa:
          </label>
          <Input id="table-number" type="text" value={tableNumber} readOnly className="w-24 bg-gray-100" />
        </div>
      </div>

      <div className="mb-6 flex-1 overflow-auto">
        <h2 className="text-lg font-semibold mb-4">Itens do Pedido</h2>
        {currentOrder.items.length === 0 ? (
          <p className="text-muted-foreground">Nenhum item adicionado ao pedido.</p>
        ) : (
          <ul className="space-y-2">
            {currentOrder.items.map((item) => (
              <li key={item.id} className="flex justify-between items-center">
                <span>
                  {item.name} x {item.quantity}
                </span>
                <span>R${(item.price * item.quantity).toFixed(2)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {currentOrder.items.length === 0 ? (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">Nenhum item adicionado</div>
      ) : (
        <>
          <div className="mt-auto">
            <div className="space-y-2 mb-6">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>R${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Desconto</span>
                <span>-R${discount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Taxa de serviço (10%)</span>
                <span>R${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-medium text-lg pt-2 border-t">
                <span>Total</span>
                <span>R${total.toFixed(2)}</span>
              </div>
            </div>

            <div className="space-y-4">
              <Button
                className="w-full bg-red-600 hover:bg-red-700 text-white"
                onClick={handleFinishOrder}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Enviando..." : "Finalizar Pedido"}
              </Button>
            </div>
          </div>
        </>
      )}

      <Dialog open={isConfirmationOpen} onOpenChange={setIsConfirmationOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Finalização do Pedido</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja finalizar este pedido para a Mesa {tableNumber}?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmationOpen(false)}>
              Cancelar
            </Button>
            <Button
              onClick={confirmFinishOrder}
              className="bg-red-600 hover:bg-red-700 text-white"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Enviando..." : "Confirmar Finalização"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

