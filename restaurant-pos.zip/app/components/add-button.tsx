import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"

export function AddButton() {
  return (
    <Button
      size="icon"
      className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-emerald-500 hover:bg-emerald-600 shadow-lg"
    >
      <Plus className="h-6 w-6" />
    </Button>
  )
}

