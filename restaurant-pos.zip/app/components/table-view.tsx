"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { useTableContext, type ExtendedTable } from "../contexts/table-context"
import { useOrder } from "../contexts/order-context"
import { useToast } from "@/components/ui/use-toast"
import { RefreshCw } from "lucide-react"

interface TableViewProps {
  updateTableStatuses: () => void
}

interface Reservation {
  tableNumber: string
  name: string
  date: string
  time: string
}

export function TableView({ updateTableStatuses }: TableViewProps) {
  const { tables, updateTable } = useTableContext()
  const { orders } = useOrder()
  const [selectedTable, setSelectedTable] = useState<ExtendedTable | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false)
  const [reservationName, setReservationName] = useState("")
  const [reservationDate, setReservationDate] = useState("")
  const [reservationTime, setReservationTime] = useState("")
  const [reservations, setReservations] = useState<Reservation[]>([])
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const savedReservations = JSON.parse(localStorage.getItem("reservations") || "[]")
    setReservations(savedReservations)
  }, [])

  useEffect(() => {
    tables.forEach((table) => {
      const reservation = reservations.find((r) => r.tableNumber === table.number)
      if (reservation && table.status === "livre") {
        updateTable({
          ...table,
          status: "ocupada",
          reservationName: reservation.name,
          reservationDate: reservation.date,
          reservationTime: reservation.time,
        })
      }
    })
  }, [tables, reservations, updateTable])

  const handleTableClick = (table: ExtendedTable) => {
    setSelectedTable(table)
    setIsDialogOpen(true)
  }

  const handleMakeOrder = () => {
    if (selectedTable) {
      router.push(`/pedido?mesa=${selectedTable.number}`)
    }
  }

  const handleCloseTable = () => {
    if (selectedTable) {
      updateTable({ ...selectedTable, status: "livre" })
      setIsDialogOpen(false)
      updateTableStatuses()
    }
  }

  const handleTableProfile = (table: ExtendedTable) => {
    setSelectedTable(table)
    setIsProfileDialogOpen(true)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "livre":
        return "bg-green-400"
      case "ocupada":
        return "bg-blue-400"
      case "esperando":
        return "bg-yellow-400"
      case "servida":
        return "bg-red-400"
      default:
        return "bg-gray-300"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "livre":
        return "Vacant"
      case "ocupada":
        return "Occupied"
      case "esperando":
        return "Waiting"
      case "servida":
        return "Served"
      default:
        return status
    }
  }

  const handleReservation = () => {
    if (selectedTable && reservationName && reservationDate && reservationTime) {
      const reservationData: Reservation = {
        tableNumber: selectedTable.number,
        name: reservationName,
        date: reservationDate,
        time: reservationTime,
      }

      const newReservations = [...reservations, reservationData]
      setReservations(newReservations)
      localStorage.setItem("reservations", JSON.stringify(newReservations))

      updateTable({
        ...selectedTable,
        status: "ocupada",
        reservationName,
        reservationDate,
        reservationTime,
      })
      setIsProfileDialogOpen(false)
      setReservationName("")
      setReservationDate("")
      setReservationTime("")
      updateTableStatuses()
      toast({
        title: "Reserva salva com sucesso",
        description: `Mesa ${selectedTable.number} reservada para ${reservationName} em ${reservationDate} às ${reservationTime}. Status: Ocupada`,
      })
    } else {
      toast({
        title: "Erro na reserva",
        description: "Por favor, preencha todos os campos da reserva.",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    orders.forEach((order) => {
      const table = tables.find((t) => t.number === order.tableNumber)
      if (table) {
        if (order.status === "pending" || order.status === "preparing") {
          updateTable({ ...table, status: "esperando" })
        } else if (order.status === "ready") {
          updateTable({ ...table, status: "servida" })
        }
      }
    })
  }, [orders, tables, updateTable])

  // Ordenar as mesas em ordem crescente
  const sortedTables = [...tables].sort((a, b) => {
    const numA = Number.parseInt(a.number)
    const numB = Number.parseInt(b.number)
    return numA - numB
  })

  const resetAllTables = () => {
    tables.forEach((table) => {
      updateTable({ ...table, status: "livre" })
    })
    setReservations([])
    localStorage.removeItem("reservations")
    updateTableStatuses()
    toast({
      title: "Mesas resetadas",
      description: "Todas as mesas foram definidas como livres.",
    })
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Mesas</h1>
        <Button
          onClick={() => {
            const password = prompt("Digite a senha para resetar as mesas:")
            if (password === "1234") {
              resetAllTables()
            } else {
              toast({
                title: "Erro",
                description: "Senha incorreta. Não foi possível resetar as mesas.",
                variant: "destructive",
              })
            }
          }}
          className="bg-red-600 hover:bg-red-700 text-white"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Resetar Mesas
        </Button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {sortedTables.map((table) => (
          <div key={table.id} className="relative">
            {/* Table Card */}
            <div className="flex flex-col">
              <button
                onClick={() => handleTableClick(table)}
                className="w-full h-32 bg-white rounded-lg shadow-md transition-all duration-200 hover:shadow-lg relative"
              >
                {/* Main table square */}
                <div className={`absolute inset-2 ${getStatusColor(table.status)} rounded-md`}></div>

                {/* Chairs (semi-circles) */}
                <div className="absolute inset-0">
                  {/* Left chair */}
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-8 bg-gray-300 rounded-l-full"></div>
                  {/* Right chair */}
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-4 h-8 bg-gray-300 rounded-r-full"></div>
                  {/* Top chair */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 h-4 w-8 bg-gray-300 rounded-t-full"></div>
                  {/* Bottom chair */}
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 h-4 w-8 bg-gray-300 rounded-b-full"></div>
                </div>

                {/* Content */}
                <div className="absolute inset-0 flex flex-col justify-between items-center p-4 z-10 bg-white rounded-md">
                  <div className="text-3xl font-light text-black">{table.number.padStart(2, "0")}</div>
                  <div className="text-sm font-medium text-black">{getStatusText(table.status)}</div>
                  {table.reservationTime && <div className="text-xs text-black">{table.reservationTime}</div>}
                </div>
              </button>
              <Button
                onClick={() => handleTableProfile(table)}
                className="mt-2 w-full text-xs bg-gray-100 hover:bg-gray-200 text-gray-600"
              >
                Perfil
              </Button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mesa {selectedTable?.number}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Button onClick={handleMakeOrder} className="w-full">
              Fazer Pedido
            </Button>
            {selectedTable?.status !== "livre" && (
              <Button onClick={handleCloseTable} variant="outline" className="w-full">
                Fechar Mesa
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isProfileDialogOpen} onOpenChange={setIsProfileDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Perfil da Mesa {selectedTable?.number}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label htmlFor="status" className="block text-sm font-medium text-gray-700">
                Status
              </label>
              <div id="status" className="mt-1">
                {selectedTable?.status}
              </div>
            </div>
            <div>
              <label htmlFor="reservation-name" className="block text-sm font-medium text-gray-700">
                Nome da Reserva
              </label>
              <Input
                id="reservation-name"
                value={reservationName}
                onChange={(e) => setReservationName(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <label htmlFor="reservation-date" className="block text-sm font-medium text-gray-700">
                Data da Reserva
              </label>
              <Input
                id="reservation-date"
                type="date"
                value={reservationDate}
                onChange={(e) => setReservationDate(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <label htmlFor="reservation-time" className="block text-sm font-medium text-gray-700">
                Hora da Reserva
              </label>
              <Input
                id="reservation-time"
                type="time"
                value={reservationTime}
                onChange={(e) => setReservationTime(e.target.value)}
                className="mt-1"
              />
            </div>
            <Button onClick={handleReservation} className="w-full bg-red-600 hover:bg-red-700 text-white">
              Salvar Reserva Permanentemente
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

