"use server"

import type { Order } from "../types/order"

// In a real app, this would be a database
let orders: Order[] = []
const cashRegister = { total: 0, history: [] }

export async function createOrder(order: Omit<Order, "id" | "createdAt" | "status">) {
  const newOrder = {
    ...order,
    id: Math.random().toString(36).substring(7),
    createdAt: new Date(),
    status: "pending" as const,
  }

  orders.push(newOrder)
  return newOrder
}

export async function getOrders() {
  return orders
}

export async function updateOrderStatus(orderId: string, status: Order["status"]) {
  orders = orders.map((order) => (order.id === orderId ? { ...order, status } : order))
  return orders.find((order) => order.id === orderId)
}

export async function updateCashRegister(orderData: { total: number; tableNumber: string }) {
  cashRegister.total += orderData.total
  cashRegister.history.push({
    tableNumber: orderData.tableNumber,
    total: orderData.total,
    timestamp: new Date(),
  })
  return cashRegister
}

export async function sendOrderToCaixa(order: Omit<Order, "id" | "createdAt">) {
  // In a real application, this would send the order to a cash register system
  // For now, we'll just log the order and return a success message
  console.log("Sending order to caixa:", order)
  return { success: true, message: "Order sent to caixa successfully" }
}

