import { MesaManagement } from "../components/mesa-management"
import { LayoutWrapper } from "../components/layout-wrapper"

export default function MesasPage() {
  return (
    <LayoutWrapper>
      <div className="p-6 bg-red-50">
        <h1 className="text-2xl font-bold text-red-800 mb-4">Gerenciamento de Mesas</h1>
        <MesaManagement />
      </div>
    </LayoutWrapper>
  )
}

