import { LayoutWrapper } from "../components/layout-wrapper"
import { KitchenOrderList } from "../components/kitchen-order-list"
import { OrderProvider } from "../contexts/order-context"
import { TableProvider } from "../contexts/table-context"

export default function KitchenPage() {
  return (
    <OrderProvider>
      <TableProvider>
        <LayoutWrapper>
          <KitchenOrderList />
        </LayoutWrapper>
      </TableProvider>
    </OrderProvider>
  )
}

