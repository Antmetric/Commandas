"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"

export interface OrderItem {
  name: string
  quantity: number
  price: number
}

export interface ExtendedTable {
  id: string
  number: string
  status: "livre" | "ocupada" | "esperando" | "servida"
  reservationName?: string
  reservationStartTime?: string
  reservationEndTime?: string
  orderItems?: OrderItem[]
  pendingItems?: OrderItem[]
  totalAmount?: number
  isReservation?: boolean
}

interface TableOrder {
  tableNumber: string
  items: OrderItem[]
  totalAmount: number
  date: Date
}

interface TableContextType {
  tables: ExtendedTable[]
  updateTable: (updatedTable: ExtendedTable) => void
  addTable: (newTable: ExtendedTable) => void
  removeTable: (tableId: string) => void
  tableOrders: TableOrder[]
  addTableOrder: (order: TableOrder) => void
  updateTableStatus: (tableNumber: string, newStatus: ExtendedTable["status"]) => void
}

const TableContext = createContext<TableContextType | undefined>(undefined)

const initialTables: ExtendedTable[] = [
  { id: "T1", number: "01", status: "livre" },
  { id: "T2", number: "02", status: "esperando" },
  {
    id: "T3",
    number: "03",
    status: "ocupada",
    orderItems: [{ name: "Pizza", quantity: 1, price: 20 }],
    totalAmount: 20,
  },
  { id: "T4", number: "04", status: "livre" },
  {
    id: "T5",
    number: "05",
    status: "ocupada",
    orderItems: [{ name: "Burger", quantity: 2, price: 15 }],
    totalAmount: 30,
    isReservation: true,
    reservationName: "João Silva",
    reservationStartTime: "19:00",
    reservationEndTime: "20:30",
  },
  { id: "T6", number: "06", status: "livre" },
  { id: "T7", number: "07", status: "esperando" },
  { id: "T8", number: "08", status: "livre" },
]

export const TableProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [tables, setTables] = useState<ExtendedTable[]>(() => {
    if (typeof window !== "undefined") {
      const savedTables = localStorage.getItem("tables")
      return savedTables ? JSON.parse(savedTables) : initialTables
    }
    return initialTables
  })

  const [tableOrders, setTableOrders] = useState<TableOrder[]>(() => {
    if (typeof window !== "undefined") {
      const savedOrders = localStorage.getItem("tableOrders")
      return savedOrders ? JSON.parse(savedOrders) : []
    }
    return []
  })

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("tables", JSON.stringify(tables))
      localStorage.setItem("tableOrders", JSON.stringify(tableOrders))
    }
  }, [tables, tableOrders])

  const updateTable = useCallback((updatedTable: ExtendedTable) => {
    setTables((prevTables) => prevTables.map((table) => (table.id === updatedTable.id ? updatedTable : table)))
  }, [])

  const addTable = useCallback((newTable: ExtendedTable) => {
    setTables((prevTables) => [...prevTables, newTable])
  }, [])

  const removeTable = useCallback((tableId: string) => {
    setTables((prevTables) => prevTables.filter((table) => table.id !== tableId))
  }, [])

  const addTableOrder = useCallback((order: TableOrder) => {
    setTableOrders((prevOrders) => [...prevOrders, order])
  }, [])

  const updateTableStatus = useCallback((tableNumber: string, newStatus: ExtendedTable["status"]) => {
    setTables((prevTables) =>
      prevTables.map((table) => (table.number === tableNumber ? { ...table, status: newStatus } : table)),
    )
  }, [])

  return (
    <TableContext.Provider
      value={{ tables, updateTable, addTable, removeTable, tableOrders, addTableOrder, updateTableStatus }}
    >
      {children}
    </TableContext.Provider>
  )
}

export const useTableContext = () => {
  const context = useContext(TableContext)
  if (context === undefined) {
    throw new Error("useTableContext must be used within a TableProvider")
  }
  return context
}

