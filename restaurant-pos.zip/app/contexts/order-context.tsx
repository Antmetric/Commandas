"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

export interface OrderItem {
  id: string
  name: string
  quantity: number
  price: number
}

export interface Order {
  id: string
  tableNumber: string
  items: OrderItem[]
  status: "pending" | "preparing" | "ready" | "delivered"
  createdAt: Date
  total: number
}

interface OrderContextType {
  orders: Order[]
  addOrder: (order: Order) => void
  updateOrderStatus: (orderId: string, status: Order["status"]) => void
}

const OrderContext = createContext<OrderContextType | undefined>(undefined)

export function OrderProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([])

  useEffect(() => {
    const storedOrders = localStorage.getItem("orders")
    if (storedOrders) {
      setOrders(JSON.parse(storedOrders))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("orders", JSON.stringify(orders))
  }, [orders])

  const addOrder = (order: Order) => {
    setOrders((prevOrders) => [...prevOrders, order])
  }

  const updateOrderStatus = (orderId: string, status: Order["status"]) => {
    setOrders((prevOrders) => prevOrders.map((order) => (order.id === orderId ? { ...order, status } : order)))
  }

  return <OrderContext.Provider value={{ orders, addOrder, updateOrderStatus }}>{children}</OrderContext.Provider>
}

export function useOrder() {
  const context = useContext(OrderContext)
  if (context === undefined) {
    throw new Error("useOrder must be used within an OrderProvider")
  }
  return context
}

