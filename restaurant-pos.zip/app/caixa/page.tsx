import { LayoutWrapper } from "../components/layout-wrapper"
import { Caixa } from "../components/caixa"
import { TableProvider } from "../contexts/table-context"
import { OrderProvider } from "../contexts/order-context"

export default function CaixaPage() {
  return (
    <OrderProvider>
      <TableProvider>
        <LayoutWrapper>
          <Caixa />
        </LayoutWrapper>
      </TableProvider>
    </OrderProvider>
  )
}

