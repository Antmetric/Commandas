export interface OrderItem {
  id: string
  name: string
  quantity: number
  price: number
}

export interface Order {
  id: string
  tableNumber: string
  items: OrderItem[]
  status: "pending" | "preparing" | "ready" | "delivered" | "paid" | "cancelled"
  createdAt: Date
  total: number
}

