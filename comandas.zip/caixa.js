const orders = [
  {
    id: 1,
    tableNumber: 1,
    items: [
      { name: "Pizza Margherita", quantity: 1, price: 10.99 },
      { name: "Coca-Cola", quantity: 2, price: 2.5 },
    ],
  },
  {
    id: 2,
    tableNumber: 2,
    items: [
      { name: "Spaghetti Carbonara", quantity: 1, price: 12.99 },
      { name: "Wine", quantity: 1, price: 7.99 },
    ],
  },
  {
    id: 3,
    tableNumber: 1,
    items: [{ name: "Tiramisu", quantity: 2, price: 6.99 }],
  },
]

function renderTableButtons() {
  const tableButtons = document.getElementById("table-buttons")
  const tables = [...new Set(orders.map((order) => order.tableNumber))]
  tableButtons.innerHTML = tables
    .map((table) => `<button onclick="showOrderHistory('${table}')">Mesa ${table}</button>`)
    .join("")
}

function showOrderHistory(tableNumber) {
  const orderHistory = document.getElementById("order-history")
  const tableOrders = orders.filter((order) => order.tableNumber === tableNumber)
  orderHistory.innerHTML = `
        <h2>Histórico da Mesa ${tableNumber}</h2>
        ${tableOrders
          .map(
            (order) => `
            <div class="order">
                <h3>Pedido #${order.id}</h3>
                <ul>
                    ${order.items
                      .map(
                        (item) => `
                        <li>${item.name} x${item.quantity} - €${(item.price * item.quantity).toFixed(2)}</li>
                    `,
                      )
                      .join("")}
                </ul>
                <p>Total: €${order.items.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)}</p>
            </div>
        `,
          )
          .join("")}
    `
}

// Initialize the cash register view
renderTableButtons()

