const tables = [
  { id: 1, number: "1", status: "occupied", amount: 25.5, time: "14:30" },
  { id: 2, number: "2", status: "free", amount: null, time: null },
  { id: 3, number: "3", status: "occupied", amount: 12.75, time: "15:00" },
]

const showOrderView = (tableId) => {
  console.log(`Showing order view for table ID: ${tableId}`)
  // Add your order view logic here
}

function renderTables() {
  const tableGrid = document.getElementById("table-grid")
  tableGrid.innerHTML = ""
  tables.forEach((table) => {
    const tableElement = document.createElement("div")
    tableElement.className = `table ${table.status}`
    tableElement.innerHTML = `
            <h2>${table.number}</h2>
            ${table.amount ? `<p>€${table.amount.toFixed(2)}</p>` : ""}
            ${table.time ? `<p>${table.time}</p>` : ""}
        `
    tableElement.addEventListener("click", () => showOrderView(table.id))
    tableGrid.appendChild(tableElement)
  })
}

// Initialize the table view
renderTables()

