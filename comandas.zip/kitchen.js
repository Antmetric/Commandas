let orders = [] // Declare the orders variable

function renderOrders() {
  const orderList = document.getElementById("order-list")
  orderList.innerHTML = ""
  orders.forEach((order) => {
    const orderElement = document.createElement("div")
    orderElement.className = "order"
    orderElement.innerHTML = `
            <h2>Mesa ${order.tableNumber}</h2>
            <ul>
                ${order.items.map((item) => `<li>${item.name} x${item.quantity}</li>`).join("")}
            </ul>
            <p>Status: ${order.status}</p>
            <button onclick="updateOrderStatus(${order.id}, 'preparing')">Iniciar Preparo</button>
            <button onclick="updateOrderStatus(${order.id}, 'ready')">Pronto</button>
        `
    orderList.appendChild(orderElement)
  })
}

function updateOrderStatus(orderId, newStatus) {
  const order = orders.find((o) => o.id === orderId)
  if (order) {
    order.status = newStatus
    renderOrders()
  }
}

// Initialize the kitchen view
// Assuming orders is populated elsewhere, for example:
// fetch('/orders')
//   .then(response => response.json())
//   .then(data => {
//     orders = data;
//     renderOrders();
//   });

//For testing purposes, let's add some sample data:
orders = [
  { id: 1, tableNumber: 1, items: [{ name: "Pizza", quantity: 2 }], status: "pending" },
  {
    id: 2,
    tableNumber: 2,
    items: [
      { name: "Pasta", quantity: 1 },
      { name: "Salad", quantity: 1 },
    ],
    status: "pending",
  },
]
renderOrders()

