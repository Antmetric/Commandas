// Sample data
const tables = [
  { id: "T1", number: "T1", status: "available" },
  { id: "T2", number: "T2", status: "occupied", amount: 345.6, time: "0:10h" },
  { id: "T3", number: "T3", status: "available" },
  { id: "T4", number: "T4", status: "occupied", amount: 123.4, time: "0:30h" },
]

const orders = []

const menuItems = [
  { id: 1, name: "Burger", price: 10 },
  { id: 2, name: "Pizza", price: 15 },
  { id: 3, name: "Salad", price: 8 },
  { id: 4, name: "Soda", price: 2 },
]

let currentOrder = { items: [], tableNumber: null }

// Navigation
document.getElementById("home-btn").addEventListener("click", () => (window.location.href = "index.html"))
document.getElementById("kitchen-btn").addEventListener("click", () => (window.location.href = "kitchen.html"))
document.getElementById("cash-btn").addEventListener("click", () => (window.location.href = "caixa.html"))

function showOrderView(tableId) {
  currentOrder.tableNumber = tableId
  const mainContent = document.getElementById("main-content")
  mainContent.innerHTML = `
        <h1>Novo Pedido - Mesa ${currentOrder.tableNumber}</h1>
        <div class="menu-grid" id="menu-grid"></div>
        <div class="order-summary" id="order-summary"></div>
    `
  renderMenu()
  renderOrderSummary()
}

function renderMenu() {
  const menuGrid = document.getElementById("menu-grid")
  menuGrid.innerHTML = ""
  menuItems.forEach((item) => {
    const itemElement = document.createElement("div")
    itemElement.className = "menu-item"
    itemElement.innerHTML = `
            <h3>${item.name}</h3>
            <p>€${item.price.toFixed(2)}</p>
            <button onclick="addToOrder(${item.id})">Adicionar</button>
        `
    menuGrid.appendChild(itemElement)
  })
}

function addToOrder(itemId) {
  const item = menuItems.find((i) => i.id === itemId)
  const existingItem = currentOrder.items.find((i) => i.id === itemId)
  if (existingItem) {
    existingItem.quantity += 1
  } else {
    currentOrder.items.push({ ...item, quantity: 1 })
  }
  renderOrderSummary()
}

function renderOrderSummary() {
  const orderSummary = document.getElementById("order-summary")
  const total = currentOrder.items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  orderSummary.innerHTML = `
        <h2>Resumo do Pedido</h2>
        <ul>
            ${currentOrder.items
              .map(
                (item) => `
                <li>${item.name} x${item.quantity} - €${(item.price * item.quantity).toFixed(2)}</li>
            `,
              )
              .join("")}
        </ul>
        <p>Total: €${total.toFixed(2)}</p>
        <button onclick="finishOrder()">Finalizar Pedido</button>
    `
}

function finishOrder() {
  if (currentOrder.items.length > 0) {
    orders.push({ ...currentOrder, id: Date.now(), status: "pending" })
    currentOrder = { items: [], tableNumber: null }
    window.location.href = "kitchen.html"
  } else {
    alert("Adicione itens ao pedido antes de finalizar.")
  }
}

