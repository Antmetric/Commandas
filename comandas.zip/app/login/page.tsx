"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import Link from "next/link"

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("isAuthenticated")
    if (isAuthenticated === "true") {
      router.replace("/")
    }
  }, [router])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password === "1234") {
      localStorage.setItem("isAuthenticated", "true")
      alert("Login realizado com sucesso!")
      router.replace("/")
    } else {
      alert("Senha inválida. Por favor, tente novamente.")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 via-white to-gray-100">
      <div className="max-w-md mx-auto px-6 pt-32">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 mb-6 rounded-full bg-gradient-to-r from-gray-200 to-gray-100 flex items-center justify-center shadow-lg">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagem%20do%20WhatsApp%20de%202025-02-22%20%C3%A0(s)%2000.52.39_55081459.jpg-mMwbqzZIJck1saPbgW1UagIIwQMsLX.jpeg"
              alt="Logo"
              width={48}
              height={48}
              className="rounded-full"
            />
          </div>
          <h1 className="text-2xl font-medium text-gray-800 mb-2">Olá, bem-vindo de volta!</h1>
          <p className="text-gray-500">Bem-vindo ao nosso sistema de gerenciamento de restaurante.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <Input
              type="text"
              placeholder="Nome de usuário"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="h-12 bg-white border-gray-200 shadow-sm hover:border-gray-300 focus:border-red-500 focus:ring-red-500"
            />
            <Input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 bg-white border-gray-200 shadow-sm hover:border-gray-300 focus:border-red-500 focus:ring-red-500"
            />
          </div>
          <Button
            type="submit"
            className="w-full h-12 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white shadow-lg"
          >
            Entrar
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button className="text-gray-600 hover:text-gray-900 text-sm font-medium">Entrar usando link mágico</button>
        </div>

        <div className="mt-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-gray-200" />
          <span className="text-gray-400 text-sm">ou</span>
          <div className="h-px flex-1 bg-gray-200" />
        </div>

        <button className="mt-6 w-full h-12 border border-gray-200 rounded-lg text-gray-700 hover:bg-gray-50 hover:border-gray-300 shadow-sm transition-all">
          Login único (SSO)
        </button>

        <p className="mt-8 text-center text-xs text-gray-500">
          Você reconhece que leu e concorda com nossos{" "}
          <Link href="/terms" className="text-red-600 hover:text-red-700">
            Termos de Serviço
          </Link>{" "}
          e nossa{" "}
          <Link href="/privacy" className="text-red-600 hover:text-red-700">
            Política de Privacidade
          </Link>
          .
        </p>
      </div>
    </div>
  )
}

