"use client"

import { useSearchParams } from "next/navigation"
import { useRouter } from "next/navigation"
import { LayoutWrapper } from "../components/layout-wrapper"
import { Menu } from "../components/menu"
import { OrderSummary } from "../components/order-summary"
import { OrderProvider } from "../contexts/order-context"
import { TableProvider } from "../contexts/table-context"

export default function PedidoPage() {
  const searchParams = useSearchParams()
  const mesa = searchParams.get("mesa")
  const router = useRouter()

  return (
    <OrderProvider>
      <TableProvider>
        <LayoutWrapper>
          <div className="flex h-full">
            <div className="flex-grow overflow-auto">
              <Menu />
            </div>
            <div className="w-[400px] border-l bg-white">
              <OrderSummary />
            </div>
          </div>
        </LayoutWrapper>
      </TableProvider>
    </OrderProvider>
  )
}

