"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { LayoutWrapper } from "./components/layout-wrapper"
import { OrderProvider } from "./contexts/order-context"
import { TableProvider } from "./contexts/table-context"
import { TableView } from "./components/table-view"
import { Caixa } from "./components/caixa"
import { KitchenOrderList } from "./components/kitchen-order-list"
import { AdminDashboard } from "./components/admin-dashboard"
import { Menu } from "./components/menu"

function MainContent() {
  const [currentView, setCurrentView] = useState<"mesas" | "cozinha" | "caixa" | "admin" | "menu">("mesas")

  const renderContent = () => {
    switch (currentView) {
      case "mesas":
        return <TableView updateTableStatuses={() => {}} />
      case "cozinha":
        return <KitchenOrderList />
      case "caixa":
        return <Caixa />
      case "admin":
        return <AdminDashboard />
      case "menu":
        return <Menu />
      default:
        return <TableView updateTableStatuses={() => {}} />
    }
  }

  return <LayoutWrapper>{renderContent()}</LayoutWrapper>
}

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const router = useRouter()

  useEffect(() => {
    const authStatus = localStorage.getItem("isAuthenticated")
    setIsAuthenticated(authStatus === "true")

    if (authStatus !== "true") {
      router.replace("/login")
    }
  }, [router])

  if (isAuthenticated === null) {
    return <div>Carregando...</div>
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <OrderProvider>
      <TableProvider>
        <MainContent />
      </TableProvider>
    </OrderProvider>
  )
}

