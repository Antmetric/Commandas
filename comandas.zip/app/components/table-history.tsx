import type { TableLog } from "../data/shared-data"
import { formatCurrency } from "../utils/format-currency"

interface TableHistoryProps {
  logs: TableLog[]
}

export function TableHistory({ logs }: TableHistoryProps) {
  return (
    <div className="space-y-6">
      {logs.map((log, index) => (
        <div key={index} className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold mb-2">Mesa {log.tableNumber}</h3>
          <p className="text-sm text-gray-600 mb-4">
            Ocupação: {log.occupationStart.toLocaleString()} - {log.occupationEnd.toLocaleString()}
          </p>
          <table className="w-full mb-4">
            <thead>
              <tr className="text-left text-sm font-medium text-gray-500">
                <th className="pb-2">Item</th>
                <th className="pb-2">Qtd</th>
                <th className="pb-2">Preço Unit.</th>
                <th className="pb-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {log.items.map((item, itemIndex) => (
                <tr key={itemIndex} className="text-sm">
                  <td className="py-1">{item.name}</td>
                  <td className="py-1">{item.quantity}</td>
                  <td className="py-1">{formatCurrency(item.unitPrice)}</td>
                  <td className="py-1">{formatCurrency(item.totalPrice)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="text-right font-semibold">Total: {formatCurrency(log.totalAmount)}</p>
        </div>
      ))}
    </div>
  )
}

