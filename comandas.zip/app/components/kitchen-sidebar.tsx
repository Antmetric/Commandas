import { ClipboardList, Clock, History, Settings, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"

export function KitchenSidebar() {
  return (
    <div className="w-[72px] h-screen flex flex-col items-center py-6 border-r bg-white">
      <Button
        variant="ghost"
        size="icon"
        className="rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200 hover:text-blue-700"
      >
        <ClipboardList className="h-5 w-5" />
      </Button>
      <div className="flex-1 flex flex-col gap-4 mt-8">
        <Button variant="ghost" size="icon" title="Pedidos Ativos">
          <Clock className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" title="Histórico">
          <History className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" title="Notificações">
          <Bell className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" title="Configurações">
          <Settings className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}

