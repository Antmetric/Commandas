"use client"

import { useOrder } from "../contexts/order-context"
import { useTableContext } from "../contexts/table-context"
import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { QRCodeSVG } from "qrcode.react"
import type { Order } from "@/lib/types"

export function Caixa() {
  const { orders, updateOrderStatus } = useOrder()
  const { tables, updateTable, updateTableStatus } = useTableContext()
  const readyOrders = orders.filter((order) => order.status === "ready")

  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [isConfirmationDialogOpen, setIsConfirmationDialogOpen] = useState(false)
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null)

  const [savedPixKey, setSavedPixKey] = useState("")
  const [savedQrCode, setSavedQrCode] = useState("")

  useEffect(() => {
    const pixKey = localStorage.getItem("pixKey")
    const qrCode = localStorage.getItem("qrCodeImage")
    if (pixKey) setSavedPixKey(pixKey)
    if (qrCode) setSavedQrCode(qrCode)
  }, [])

  const handlePayment = (order: Order) => {
    setCurrentOrder(order)
    setIsConfirmationDialogOpen(true)
  }

  const confirmPayment = () => {
    setIsConfirmationDialogOpen(false)
    setIsPaymentDialogOpen(true)
  }

  const finalizePayment = () => {
    if (currentOrder) {
      // Mark the current order as paid
      updateOrderStatus(currentOrder.id, "paid")

      // Mark all other ready orders for this table as paid
      readyOrders
        .filter((order) => order.tableNumber === currentOrder.tableNumber && order.id !== currentOrder.id)
        .forEach((order) => updateOrderStatus(order.id, "paid"))

      // Update table status
      updateTableStatus(currentOrder.tableNumber, "livre")

      // Log the order in HistóricoADM
      const orderLog = {
        id: currentOrder.id,
        tableNumber: currentOrder.tableNumber,
        items: currentOrder.items,
        total: currentOrder.total,
        timestamp: new Date().toISOString(),
      }

      // Store in localStorage for HistóricoADM
      const existingLogs = JSON.parse(localStorage.getItem("orderHistory") || "[]")
      localStorage.setItem("orderHistory", JSON.stringify([orderLog, ...existingLogs]))

      setIsPaymentDialogOpen(false)
      setCurrentOrder(null)
    }
  }

  return (
    <div className="flex h-full">
      <div className="flex-1 p-6">
        <h1 className="text-2xl font-bold mb-4">Caixa</h1>
        {/* Conteúdo principal do caixa aqui */}
      </div>
      <div className="w-80 bg-gray-100 p-4 overflow-y-auto">
        <h2 className="text-xl font-semibold mb-4">Pedidos Prontos</h2>
        <div className="space-y-4">
          {readyOrders.map((order) => (
            <div key={order.id} className="bg-white border p-4 rounded-lg shadow">
              <h3 className="text-lg font-semibold">Mesa {order.tableNumber}</h3>
              <ul className="mt-2 mb-3">
                {order.items.map((item, index) => (
                  <li key={index}>
                    {item.name} x{item.quantity} - R$ {item.price * item.quantity}
                  </li>
                ))}
              </ul>
              <p className="font-bold mb-2">Total: R$ {order.total.toFixed(2)}</p>
              <Button onClick={() => handlePayment(order)} className="w-full">
                Registrar Pagamento
              </Button>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={isConfirmationDialogOpen} onOpenChange={setIsConfirmationDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar Pagamento</DialogTitle>
          </DialogHeader>
          {currentOrder && (
            <div className="mt-4">
              <h3 className="text-lg font-semibold mb-2">Mesa {currentOrder.tableNumber}</h3>
              <ul className="mb-3">
                {currentOrder.items.map((item, index) => (
                  <li key={index}>
                    {item.name} x{item.quantity} - R$ {item.price * item.quantity}
                  </li>
                ))}
              </ul>
              <p className="font-bold text-lg mb-4">Total: R$ {currentOrder.total.toFixed(2)}</p>
              <Button onClick={confirmPayment} className="w-full">
                Confirmar e Prosseguir para Pagamento
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Pagamento</DialogTitle>
          </DialogHeader>
          {currentOrder && (
            <div className="mt-4">
              <p className="font-bold text-lg mb-4">Total: R$ {currentOrder.total.toFixed(2)}</p>
              <p className="font-semibold mb-1">Chave PIX:</p>
              <p className="mb-4 p-2 bg-gray-100 rounded">{savedPixKey || "Chave PIX não configurada"}</p>
              <p className="font-semibold mb-2">QR CODE</p>
              <div className="flex justify-center mb-4">
                {savedQrCode ? (
                  <img src={savedQrCode || "/placeholder.svg"} alt="QR Code PIX" className="w-48 h-48" />
                ) : (
                  <QRCodeSVG value={savedPixKey} size={200} />
                )}
              </div>
              <Button onClick={finalizePayment} className="w-full bg-green-600 hover:bg-green-700 text-white">
                Confirmar Pagamento e Registrar
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

