"use client"

import { useOrder } from "../contexts/order-context"
import { useTableContext } from "../contexts/table-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useState, useEffect } from "react"

export function KitchenOrderList() {
  const { orders, updateOrderStatus } = useOrder()
  const { updateTableStatus } = useTableContext()
  const [timers, setTimers] = useState<{ [orderId: string]: number }>({})
  const pendingOrders = orders.filter((order) => order.status === "pending" || order.status === "preparing")

  useEffect(() => {
    const interval = setInterval(() => {
      setTimers((prevTimers) => {
        const newTimers = { ...prevTimers }
        pendingOrders.forEach((order) => {
          if (order.status === "preparing" && newTimers[order.id] !== undefined) {
            newTimers[order.id]++
          }
        })
        return newTimers
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [pendingOrders])

  const handleUpdateStatus = (orderId: string, newStatus: "preparing" | "ready") => {
    updateOrderStatus(orderId, newStatus)
    if (newStatus === "preparing") {
      setTimers((prevTimers) => ({ ...prevTimers, [orderId]: 0 }))
    } else if (newStatus === "ready") {
      const order = orders.find((o) => o.id === orderId)
      if (order) {
        updateTableStatus(order.tableNumber, "servida")
      }
      setTimers((prevTimers) => {
        const newTimers = { ...prevTimers }
        delete newTimers[orderId]
        return newTimers
      })
    }
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Pedidos na Cozinha</h1>
      <div className="space-y-8">
        {pendingOrders.map((order) => (
          <Card key={order.id} className="bg-white shadow-lg">
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <div className="flex items-center">
                  <span>Mesa {order.tableNumber}</span>
                  {order.status === "preparing" && timers[order.id] !== undefined && (
                    <span className="ml-2 text-xl font-bold text-red-600">
                      {Math.floor(timers[order.id] / 60)}:{(timers[order.id] % 60).toString().padStart(2, "0")}
                    </span>
                  )}
                </div>
                <span className="text-sm font-normal">
                  Pedido #{order.id.slice(-4)} • {new Date(order.createdAt).toLocaleTimeString()}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside mb-4">
                {order.items.map((item, index) => (
                  <li key={index} className="mb-2">
                    <span className="font-medium">{item.quantity}x</span> {item.name} - R$ {item.price.toFixed(2)}
                  </li>
                ))}
              </ul>
              <div className="flex justify-between items-center">
                <span className="font-bold">Total: R$ {order.total.toFixed(2)}</span>
                <div>
                  {order.status === "pending" && (
                    <Button onClick={() => handleUpdateStatus(order.id, "preparing")} className="mr-2">
                      Iniciar Preparo
                    </Button>
                  )}
                  {order.status === "preparing" && (
                    <Button onClick={() => handleUpdateStatus(order.id, "ready")}>Marcar como Pronto</Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

