"use client"

import type React from "react"

import { Home, Clock, FileText, Settings, HelpCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import Image from "next/image"

export function Sidebar() {
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated")
    router.push("/login")
  }

  return (
    <div className="w-16 sm:w-20 h-screen flex flex-col items-center py-4 border-r bg-red-600">
      <div className="w-10 h-10 sm:w-12 sm:h-12 mb-6">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Imagem%20do%20WhatsApp%20de%202025-02-22%20%C3%A0(s)%2000.52.39_55081459.jpg-mMwbqzZIJck1saPbgW1UagIIwQMsLX.jpeg"
          alt="Logo"
          width={48}
          height={48}
          className="w-full h-full object-contain rounded-full"
        />
      </div>
      <div className="flex-1 flex flex-col gap-3 sm:gap-4">
        <SidebarButton icon={<Home className="h-5 w-5" />} onClick={() => router.push("/")} title="Mesa" />
        <SidebarButton icon={<Clock className="h-5 w-5" />} onClick={() => router.push("/caixa")} title="Caixa" />
        <SidebarButton
          icon={<FileText className="h-5 w-5" />}
          onClick={() => router.push("/kitchen")}
          title="Ver Pedidos da Cozinha"
        />
        <SidebarButton
          icon={<Settings className="h-5 w-5" />}
          onClick={() => router.push("/admin")}
          title="Administração"
        />
      </div>
      <div className="flex flex-col gap-3 sm:gap-4">
        <SidebarButton icon={<HelpCircle className="h-5 w-5" />} onClick={() => {}} title="Ajuda" />
        <SidebarButton
          icon={<LogOut className="h-5 w-5" />}
          onClick={handleLogout}
          title="Sair e voltar para a página de login"
        />
      </div>
    </div>
  )
}

function SidebarButton({ icon, onClick, title }: { icon: React.ReactNode; onClick: () => void; title: string }) {
  return (
    <Button
      variant="ghost"
      size="icon"
      className="w-10 h-10 sm:w-12 sm:h-12 bg-red-500 hover:bg-red-400 text-white rounded-full"
      onClick={onClick}
      title={title}
    >
      {icon}
    </Button>
  )
}

