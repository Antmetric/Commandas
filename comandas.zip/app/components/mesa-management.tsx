"use client"

import { useState } from "react"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AlertDescription } from "@/components/ui/alert"

interface Mesa {
  id: string
  numero: string
  status: "livre" | "aguardando" | "ocupada"
  horarioChegada?: string
  capacidade: number
  ocupantes: string[]
}

export function MesaManagement() {
  const [mesas, setMesas] = useState<Mesa[]>([])
  const [novaMesa, setNovaMesa] = useState("")
  const [mesaSelecionada, setMesaSelecionada] = useState<Mesa | null>(null)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [ocupantes, setOcupantes] = useState<string[]>([])
  const [showReservaDialog, setShowReservaDialog] = useState(false)

  const adicionarMesa = () => {
    if (novaMesa) {
      const novaMesaObj: Mesa = {
        id: Date.now().toString(),
        numero: novaMesa,
        status: "livre",
        capacidade: 4,
        ocupantes: [],
      }
      setMesas([...mesas, novaMesaObj])
      setNovaMesa("")
    }
  }

  const abrirDetalhesMesa = (mesa: Mesa) => {
    setMesaSelecionada(mesa)
    if (mesa.status === "livre") {
      setShowReservaDialog(true)
    } else {
      setShowConfirmation(true)
    }
  }

  const fecharDetalhesMesa = () => {
    setMesaSelecionada(null)
    setShowConfirmation(false)
    setShowReservaDialog(false)
    setOcupantes([])
  }

  const realizarReserva = () => {
    if (mesaSelecionada) {
      const mesaAtualizada = {
        ...mesaSelecionada,
        status: "aguardando",
        ocupantes: ocupantes.filter((o) => o !== ""),
        horarioChegada: new Date().toLocaleTimeString(),
      }
      setMesas(mesas.map((m) => (m.id === mesaSelecionada.id ? mesaAtualizada : m)))
      fecharDetalhesMesa()
    }
  }

  const alterarStatusMesa = (novoStatus: Mesa["status"]) => {
    if (mesaSelecionada) {
      const mesaAtualizada = { ...mesaSelecionada, status: novoStatus }
      setMesas(mesas.map((m) => (m.id === mesaSelecionada.id ? mesaAtualizada : m)))
      fecharDetalhesMesa()
    }
  }

  const getStatusColor = (status: Mesa["status"]) => {
    switch (status) {
      case "livre":
        return "border-white"
      case "aguardando":
        return "border-gray-500"
      case "ocupada":
        return "border-red-500"
    }
  }

  return (
    <div className="p-4">
      <div className="mb-4 flex">
        <Input
          type="text"
          value={novaMesa}
          onChange={(e) => setNovaMesa(e.target.value)}
          placeholder="Número da nova mesa"
          className="mr-2"
        />
        <Button onClick={adicionarMesa} className="bg-red-600 hover:bg-red-700 text-white">
          <Plus className="mr-2 h-4 w-4" /> Adicionar Mesa
        </Button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {mesas.map((mesa) => (
          <Button
            key={mesa.id}
            className={`p-4 ${getStatusColor(mesa.status)} border-2`}
            onClick={() => abrirDetalhesMesa(mesa)}
          >
            Mesa {mesa.numero}
          </Button>
        ))}
      </div>

      {mesaSelecionada && showConfirmation && (
        <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirmação</DialogTitle>
            </DialogHeader>
            <AlertDescription>Ao aceitar, você alterará o status da mesa. Deseja continuar?</AlertDescription>
            <div className="flex justify-end gap-2 mt-4">
              <Button onClick={() => alterarStatusMesa("ocupada")} className="bg-red-600 hover:bg-red-700 text-white">
                Sim
              </Button>
              <Button onClick={fecharDetalhesMesa} variant="outline">
                Não
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {mesaSelecionada && showReservaDialog && (
        <Dialog open={showReservaDialog} onOpenChange={setShowReservaDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reserva - Mesa {mesaSelecionada.numero}</DialogTitle>
            </DialogHeader>
            <div>
              <p>Capacidade: {mesaSelecionada.capacidade} lugares</p>
              {Array.from({ length: mesaSelecionada.capacidade }).map((_, index) => (
                <Input
                  key={index}
                  type="text"
                  value={ocupantes[index] || ""}
                  onChange={(e) => {
                    const newOcupantes = [...ocupantes]
                    newOcupantes[index] = e.target.value
                    setOcupantes(newOcupantes)
                  }}
                  placeholder={`Nome do ocupante ${index + 1}`}
                  className="mt-2"
                />
              ))}
              <div className="flex justify-end gap-2 mt-4">
                <Button onClick={realizarReserva} className="bg-red-600 hover:bg-red-700 text-white">
                  Realizar Reserva
                </Button>
                <Button onClick={fecharDetalhesMesa} variant="outline">
                  Cancelar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

