"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Trash2, Edit } from "lucide-react"
import { useTableContext, type ExtendedTable } from "../contexts/table-context"

interface AdminPanelProps {
  setCurrentView: (view: "mesas" | "cozinha" | "caixa" | "admin") => void
}

export function AdminPanel({ setCurrentView }: AdminPanelProps) {
  const { tables, addTable, updateTable, removeTable } = useTableContext()
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [newTableNumber, setNewTableNumber] = useState("")
  const [editingTable, setEditingTable] = useState<ExtendedTable | null>(null)

  const handleAddTable = () => {
    if (newTableNumber) {
      addTable({
        id: Date.now().toString(),
        number: newTableNumber,
        status: "available",
      })
      setNewTableNumber("")
      setIsAddDialogOpen(false)
    }
  }

  const handleEditTable = () => {
    if (editingTable) {
      updateTable(editingTable)
      setEditingTable(null)
      setIsEditDialogOpen(false)
    }
  }

  const handleRemoveTable = (tableId: string) => {
    if (confirm("Tem certeza que deseja remover esta mesa?")) {
      removeTable(tableId)
    }
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-4">Tópicos</h2>
        <div className="flex space-x-2">
          <Button onClick={() => setCurrentView("mesas")}>Mesas</Button>
          <Button onClick={() => setCurrentView("cozinha")}>Cozinha</Button>
          <Button onClick={() => setCurrentView("caixa")}>Caixa</Button>
        </div>
      </div>

      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-4">Gerenciamento de Mesas</h2>
        <Button onClick={() => setIsAddDialogOpen(true)} className="mb-4">
          <Plus className="mr-2 h-4 w-4" /> Adicionar Mesa
        </Button>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Número da Mesa</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tables.map((table) => (
              <TableRow key={table.id}>
                <TableCell>{table.number}</TableCell>
                <TableCell>{table.status}</TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setEditingTable(table)
                      setIsEditDialogOpen(true)
                    }}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleRemoveTable(table.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Nova Mesa</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Número da Mesa"
            value={newTableNumber}
            onChange={(e) => setNewTableNumber(e.target.value)}
          />
          <DialogFooter>
            <Button onClick={handleAddTable}>Adicionar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Mesa</DialogTitle>
          </DialogHeader>
          <Input
            placeholder="Número da Mesa"
            value={editingTable?.number || ""}
            onChange={(e) => setEditingTable((prev) => (prev ? { ...prev, number: e.target.value } : null))}
          />
          <DialogFooter>
            <Button onClick={handleEditTable}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

