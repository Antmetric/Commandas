import { TableProvider } from "../contexts/table-context"
import { AdminDashboard } from "../components/admin-dashboard"
import { LayoutWrapper } from "../components/layout-wrapper"

export default function AdminPage() {
  return (
    <TableProvider>
      <LayoutWrapper>
        <AdminDashboard />
      </LayoutWrapper>
    </TableProvider>
  )
}

