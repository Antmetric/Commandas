"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface PixContextType {
  pixKey: string
  qrCodeImage: string
  updatePixConfig: (key: string, image: string) => void
}

const PixContext = createContext<PixContextType | undefined>(undefined)

export function PixProvider({ children }: { children: React.ReactNode }) {
  const [pixKey, setPixKey] = useState("")
  const [qrCodeImage, setQrCodeImage] = useState("")

  useEffect(() => {
    const savedPixKey = localStorage.getItem("pixKey")
    const savedQrCodeImage = localStorage.getItem("qrCodeImage")
    if (savedPixKey) setPixKey(savedPixKey)
    if (savedQrCodeImage) setQrCodeImage(savedQrCodeImage)
  }, [])

  const updatePixConfig = (key: string, image: string) => {
    setPixKey(key)
    setQrCodeImage(image)
    localStorage.setItem("pixKey", key)
    localStorage.setItem("qrCodeImage", image)
  }

  return <PixContext.Provider value={{ pixKey, qrCodeImage, updatePixConfig }}>{children}</PixContext.Provider>
}

export function usePixContext() {
  const context = useContext(PixContext)
  if (context === undefined) {
    throw new Error("usePixContext must be used within a PixProvider")
  }
  return context
}

