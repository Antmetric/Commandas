export interface Table {
  id: string
  number: string
  status: "available" | "occupied" | "busy"
  amount?: number
  time?: string
}

export interface OrderItem {
  id: string
  name: string
  price: number
  quantity: number
}

export interface Order {
  id: string
  tableNumber: string
  items: OrderItem[]
  status: "pending" | "preparing" | "ready" | "delivered"
  createdAt: Date
  total: number
}

export const tables: Table[] = [
  { id: "T1", number: "01", status: "available" },
  { id: "T2", number: "02", status: "available" },
  { id: "T3", number: "03", status: "available" },
  { id: "T4", number: "04", status: "available" },
  { id: "T5", number: "05", status: "available" },
  { id: "T6", number: "06", status: "available" },
  { id: "T7", number: "07", status: "available" },
  { id: "T8", number: "08", status: "available" },
]

export let orders: Order[] = []

export interface TableLogItem {
  name: string
  quantity: number
  unitPrice: number
  totalPrice: number
}

export interface TableLog {
  tableNumber: string
  occupationStart: Date
  occupationEnd: Date
  items: TableLogItem[]
  totalAmount: number
}

export const tableLogs: TableLog[] = []

// Função para adicionar um log quando uma mesa é desocupada
export function addTableLog(tableNumber: string, tableOrders: Order[]) {
  const occupationStart = tableOrders.length > 0 ? new Date(tableOrders[0].createdAt) : new Date()
  const occupationEnd = new Date()

  const items: TableLogItem[] = tableOrders.flatMap((order) =>
    order.items.map((item) => ({
      name: item.name,
      quantity: item.quantity,
      unitPrice: item.price,
      totalPrice: item.price * item.quantity,
    })),
  )

  const totalAmount = items.reduce((sum, item) => sum + item.totalPrice, 0)

  const log: TableLog = {
    tableNumber,
    occupationStart,
    occupationEnd,
    items,
    totalAmount,
  }

  tableLogs.unshift(log) // Adiciona o log mais recente no início do array
}

// Função para desocupar uma mesa
export function vacateTable(tableNumber: string) {
  const tableIndex = tables.findIndex((table) => table.number === tableNumber)
  if (tableIndex !== -1) {
    const tableOrders = orders.filter((order) => order.tableNumber === tableNumber)
    addTableLog(tableNumber, tableOrders)

    // Atualiza o status da mesa para disponível
    tables[tableIndex].status = "available"
    tables[tableIndex].amount = undefined
    tables[tableIndex].time = undefined

    // Remove os pedidos da mesa
    orders = orders.filter((order) => order.tableNumber !== tableNumber)
  }
}

// Nova função para resetar todas as mesas para o estado "available"
export function resetAllTables() {
  tables.forEach((table) => {
    table.status = "available"
    table.amount = undefined
    table.time = undefined
  })
  orders = []
}

